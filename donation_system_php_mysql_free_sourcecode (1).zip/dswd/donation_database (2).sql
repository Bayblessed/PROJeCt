-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 28, 2018 at 03:02 AM
-- Server version: 5.6.20-log
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `donation_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_beneficiary`
--

CREATE TABLE IF NOT EXISTS `tbl_beneficiary` (
`b_id` int(11) NOT NULL,
  `validdocument` varchar(200) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(68) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_beneficiary`
--

INSERT INTO `tbl_beneficiary` (`b_id`, `validdocument`, `fname`, `lname`, `contact`, `address`, `username`, `password`, `status`) VALUES
(1, '../files/148de9c5a7a44d19e56cd9ae1a554bf67847afb0c58f6e12fa29ac7ddfca9940.pdf', 'p', 'p', 'p', 'p', 'p', '148de9c5a7a44d19e56cd9ae1a554bf67847afb0c58f6e12fa29ac7ddfca9940', 2),
(3, '../files/aaa9402664f1a41f40ebbc52c9993eb66aeb366602958fdfaa283b71e64db123.jpg', 'H', 'h', 'h', 'h', 'h', 'aaa9402664f1a41f40ebbc52c9993eb66aeb366602958fdfaa283b71e64db123', 1),
(4, '../files/f9e012396be65db022bd11de9308a9b40e04e492cc4ee8636c09fb83df4aa27b.png', 'll', 'll', 'lll', 'll', 'll', 'f9e012396be65db022bd11de9308a9b40e04e492cc4ee8636c09fb83df4aa27b', 1),
(6, '../files/6199aecf23aba7e87b2dafb8b4915260da85e3cf53568197b7e451982392fb8e.PNG', 'po', 'po', 'po', 'op', 'po', '6199aecf23aba7e87b2dafb8b4915260da85e3cf53568197b7e451982392fb8e', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_broadcastmessage`
--

CREATE TABLE IF NOT EXISTS `tbl_broadcastmessage` (
`id` int(11) NOT NULL,
  `broadcastmes` varchar(1000) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_broadcastmessage`
--

INSERT INTO `tbl_broadcastmessage` (`id`, `broadcastmes`, `date`) VALUES
(1, 'BroadCast Message!', '2018-04-28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_donor`
--

CREATE TABLE IF NOT EXISTS `tbl_donor` (
`d_id` int(11) NOT NULL,
  `validdocument` varchar(255) NOT NULL,
  `donorname` varchar(255) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(68) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_donordetail`
--

CREATE TABLE IF NOT EXISTS `tbl_donordetail` (
`dd_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `typeofdonation` text NOT NULL,
  `amount` varchar(100) NOT NULL,
  `detail` text NOT NULL,
  `date` date NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_num_file`
--

CREATE TABLE IF NOT EXISTS `tbl_num_file` (
  `fnum` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_num_file`
--

INSERT INTO `tbl_num_file` (`fnum`) VALUES
(1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_request`
--

CREATE TABLE IF NOT EXISTS `tbl_request` (
`r_id` int(11) NOT NULL,
  `ben_id` int(11) NOT NULL,
  `descriptionofrequest` varchar(100) NOT NULL,
  `amountreceived` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `remarks` text NOT NULL,
  `datez` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
`u_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(68) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `usertype` tinyint(4) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`u_id`, `username`, `password`, `fname`, `lname`, `email`, `contact`, `usertype`) VALUES
(17, 'admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'admin', 'admin', 'admin@gmail.com', '09288689630', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_volunteer`
--

CREATE TABLE IF NOT EXISTS `tbl_volunteer` (
`v_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(199) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `date_voluntered` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_beneficiary`
--
ALTER TABLE `tbl_beneficiary`
 ADD PRIMARY KEY (`b_id`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tbl_broadcastmessage`
--
ALTER TABLE `tbl_broadcastmessage`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_donor`
--
ALTER TABLE `tbl_donor`
 ADD PRIMARY KEY (`d_id`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tbl_donordetail`
--
ALTER TABLE `tbl_donordetail`
 ADD PRIMARY KEY (`dd_id`);

--
-- Indexes for table `tbl_request`
--
ALTER TABLE `tbl_request`
 ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
 ADD PRIMARY KEY (`u_id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `username_2` (`username`);

--
-- Indexes for table `tbl_volunteer`
--
ALTER TABLE `tbl_volunteer`
 ADD PRIMARY KEY (`v_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_beneficiary`
--
ALTER TABLE `tbl_beneficiary`
MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_broadcastmessage`
--
ALTER TABLE `tbl_broadcastmessage`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_donor`
--
ALTER TABLE `tbl_donor`
MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `tbl_donordetail`
--
ALTER TABLE `tbl_donordetail`
MODIFY `dd_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `tbl_request`
--
ALTER TABLE `tbl_request`
MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tbl_volunteer`
--
ALTER TABLE `tbl_volunteer`
MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
