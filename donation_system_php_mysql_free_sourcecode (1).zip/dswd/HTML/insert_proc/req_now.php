<?php
    session_start();
    require '../connect/coon.php';
    require '../objects/request.php'; 
    $d=new Request();
    $d->set_ben_id($_SESSION['id_123'],$con);
    $d->set_descriptionofrequest($_POST['desc'],$con);
    $d->set_amountreceived(0,$con);
    $d->set_status(0,$con);
    $d->set_remarks("",$con);
    $d->set_datez(date('Y-m-d'),$con);
   echo $d->insert($con);
?>