<?php require 'authen.php'; ?>
<?php 
    include'../connect/coon.php' ;
    include'../objects/donor.php'; 
    include'../objects/donordetail.php'; 
    include'../objects/beneficiary.php';
     
    include'../objects/request.php';
    $donor=new Donor();
    $bene=new Beneficiary();
    $req=new Request();
    $donate=new Donor_detail();
    $d_c    =   $donor->countz($con);
    $b_c    =   $bene->countz($con);
    $r_c    =   $req->countz($con);
    $dn_c   =   $donate->countz($con);
    $max=1000;
    ?>
<html>
     <head>
        <script src="../jquery.min.js"></script>
        <meta charset="utf-8">
        <title>DSWD</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="../jquery.min.js"></script>
        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'> 
        <!-- Bootsrap -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css"> 

        <link rel="stylesheet" href="../dist/ionicons-2.0.1/css/ionicons.min.css">
        <!-- Owl carousel -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="../assets/css/style.css">

            <script src="../assets/js/bootstrap.min.js"></script>
        <!-- Modernizr -->
        <script src="../assets/js/modernizr-2.6.2.min.js"></script> 
         
        <script src="href.js"></script>
    </head>
    <style>
        body{
            margin: 0px;
            padding: 0px;
            background-color: whitesmoke;
        }
        *{
            font-family: century gothic;
        }
        #navx{
            position: fixed;
            top: 0px;
            left: 0px;
            background-color:lightblue;
            width: 260px;
            height: 100%;
            z-index: 999;
        }
        .listx{
            margin: 0px;
            padding: 0px;
        }
        .listx li{
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 1.2em;
            border-bottom-style: solid;
            border-bottom-width: 1px;
            border-color: #222222;
            text-indent: 10px;
            font-weight:bold;
            color: darkblue; 
            cursor: pointer;
        }
        .listx li:hover{ 
            border-bottom-color: blue;
        }
        .listx li:first-child{
            background-color: dodgerblue;
            text-align: center; 
            font-size: 1.8em;
            color: white;
            font-weight: bolder;
            pointer-events: none;
        }
        .listx li:last-child{
            display: none;
        }
        #menux{
            width: 60px;
            height: 60px;
            border-radius:100%;
            position: fixed; 
            bottom: 50px;
            left: 30px;
            background-color: orange;
            box-shadow: 2px 2px 4px black;
            border-style: none;
            color: white;
            font-weight: bolder;
            text-shadow: 1px 1px 1px black;
            opacity: 0.5;
            cursor: pointer;
            display: none; 
        }
        #menux:hover{
            transition: 1s;
            opacity: 1;
        }
        *:active{
            outline-style: none !important; 
        }
        
        #contx{
             
            position: fixed;
            top: 0px;
            height: 100%;
            right:0px;
            overflow-y: auto;
        }
        @media screen and (max-width:900px){
            
            #menux{
                display: block;
            }
            #navx{
                transition: 1s;
                display: none; 
                transform: translateX(-260px);
            }
             
            .listx li:last-child{
                display: list-item;
            }
            #contx{
                left: 0px;
                width: 100% !important;
            }
        }
        .activex{
            background-color: greenyellow;
            color: white !important;
            background-color: lightblue !important;
            color: #222222;
            border-right-style: solid;
            border-right-color: darkblue !important;
            border-right-width: 2px;
            text-shadow: 1px 1px 1px rgba(0,0,0,0.4);
            pointer-events: none;
        }
        .actt{
            width:150px;
            
            text-align: center; 
        }
        .actt a{
            cursor: pointer;
            font-weight: bold;
        }
        .actt a:first-child{
            color: dodgerblue;
        }
        .actt a:last-child{
            color: crimson;
        }
        #contx{ 
            position: fixed;
            top: 0px;
            height: 100%;
            right:0px;
        }
        @media screen and (max-width:900px){
            
            #menux{
                display: block;
            }
            #navx{
                transition: 1s;
                display: none; 
                transform: translateX(-260px);
            }
             
            .listx li:last-child{
                display: list-item;
            }
            #contx{
                left: 0px;
                width: 100% !important;
            }
        }#contx{ 
            position: fixed;
            top: 0px;
            height: 100%;
            right:0px; 
        }
        @media screen and (max-width:900px){
            
            #menux{
                display: block;
            }
            #navx{
                transition: 1s;
                display: none; 
                transform: translateX(-260px);
            }
             
            .listx li:last-child{
                display: list-item;
            }
            #contx{
                left: 0px;
                width: 100% !important;
            }
        }
        #dash{
            list-style: none;
            padding: 0px;
            color:white !important;
            text-align: center;
        }
        #dash li{
            display: inline-block;
            width: 300px;
            height: 150px;
            background-color: crimson;  
        }
        
        #print{
            list-style: none;
            padding: 0px;
            color:white !important; 
            text-align: center;
        }
        #print li{
            display: inline-block; 
            padding: 10px;
            margin-bottom: 10px;
            width: 402px;
            font-size: 1.1em;
            font-weight: bolder;
            background-color: orangered;
            cursor: pointer;
        }
        @media screen and (max-width:1200px){
            #dash li{
                width: 49%;
            }
        }
        .head_{
            font-size: 1.2em;
            font-weight: bold;
            padding: 5px;
            background-color: firebrick;
            color: white;
        } 
        #graph{
            width: 500px; 
            margin-left: 10px;
            margin: auto;
        }
        #graph ul{
            
            list-style: none;
            padding: 0px;
            text-align: center;
        }
        #graph li{ 
            width:100%;
            display: block;
            margin-top: 10px;
            height: 80px; 
            color: white;
            text-shadow: 1px 1px 3px black;
        }
        .headz{ 
            background-color:grey;
        }
        #don{
            transition: 1s;
        }
    </style> 
    <body onresize="sizez()">
        <?php include'broadcast.php'; ?>
        <div id="navx">
            <ul class="listx">
                <li><img src="../assets/images/dswd-logo_final2.png" width="50%"></li>
                <li class="activex">Dashboard</li>
                <li onclick='change_location("user.php")'>Admin/Users</li>
                <li onclick='change_location("donor.php")'>Donors</li>
                <li onclick='change_location("beneficiary.php")'>Beneficiaries</li>
                <li onclick='change_location("volunteer.php")'>Volunteer</li>
                <li onclick='change_location("donate.php")'>Donate</li>
                
                <li onclick='change_location("request.php")'>Request</li>
                
                
                <li onclick='show_broad()'>Broadcast</li>
                <li onclick='change_location("process/logout.php")'>logout</li>
                <li style="color:crimson;text-shadow:1px 1px 3px black">Close</li>
            </ul>
        </div> 
        <div id="contx">
            <div style="height:65px;background-color:dodgerblue"></div>
            <hr>
           
            <div id="dashz">   
                
                <ul id="dash">
                    
                    <h1 style="margin-left:10px;"></h1>
                    <li style="background-color:greenyellow">
                        <div class="head_" style="background-color:green">No. Donations</div>
                        <div><h1><?php echo number_format($dn_c); ?></h1></div>
                    </li>
                    <li style="background-color:gold">
                        <div class="head_" style="background-color:orange">No. Requests</div>
                        <div><h1><?php echo number_format($r_c); ?></h1></div>
                    </li> 
                    <li style="background-color:lightblue">
                        <div class="head_" style="background-color:dodgerblue">No. Donors</div>
                        <div><h1><?php echo number_format($d_c); ?></h1></div>
                    </li> 
                    <li>
                        <div class="head_">No. Beneficiaries</div>
                        <div><h1><?php echo number_format($b_c); ?></h1></div>
                    </li> 
                </ul>
                <hr>
                <h1 style="margin-left:10px;">Print Reports</h1>
                <ul id="print">
                   <a href='print.php?print=d' target="blank"> <li><i class='fa fa-print'></i> Print List Of Donation</li></a>
                     <a href='print.php?print=r' target="blank"><li><i class='fa fa-print'></i>Print List Of Request</li></a>
                     <a href='print.php?print=b' target="blank"><li><i class='fa fa-print'></i>Print List Of Beneficiaries</li></a>
                </ul>
            </div> 
            <div id="graph">
                <h1>Graphs</h1>
                <ul class="graph"> 
                    <li>
                        <div class="headz head_" style="background-color:green;">Donations</div>
                        <div style="height:47px;background-color:greenyellow;" id="don"></div>
                    </li>
                     <li>
                        <div class="headz head_" style="background-color:gold;" >Requests</div>
                        <div style="height:47px;background-color:orange;" id="req"></div>
                    </li>
                    <li>
                        <div class="headz head_" style="background-color:dodgerblue;">Donors  </div>
                        <div style="height:47px;background-color:lightblue;" id="donox"></div>
                    </li> <li>
                        <div class="headz head_" style="background-color:firebrick;">Benefeciaries</div>
                        <div style="height:47px;background-color:crimson;"  id="bene"></div>
                    </li>
                </ul>
            </div>
        <button id="menux"> 
            Menu
        </button>
       
    </body>
        </html>
<script>
    function sizez(){ 
        contx.style.width=(window.innerWidth-260)+"px";
        if(document.querySelector('body').offsetWidth>1200){
        graph.style.width=(dash.getElementsByTagName('li')[0].offsetWidth*4+10)+"px";
        }else{
            graph.style.width="90%";
        }
    }
    
    window.onload=()=>{
        sizez();
        don.style.width="<?php echo ($d_c/$max)*100; ?>%";
        bene.style.width="<?php echo ($b_c/$max)*100; ?>%";
        req.style.width="<?php echo ($r_c/$max)*100; ?>%";
        donox.style.width="<?php echo ($dn_c /$max)*100; ?>%";
    }
</script>