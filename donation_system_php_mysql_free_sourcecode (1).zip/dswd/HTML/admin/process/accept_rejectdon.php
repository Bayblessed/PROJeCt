<?php
    include "../../connect/coon.php";
    include "../../objects/donordetail.php";
    $donor=new Donor_detail();
    $donor->set_id($_POST['id'],$con);
    $donor->set_status($_POST['acc'],$con);
    echo $donor->update_status($con).$_POST['id']; 
?>