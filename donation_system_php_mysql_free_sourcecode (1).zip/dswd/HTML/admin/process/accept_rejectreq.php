<?php
    include "../../connect/coon.php";
    include "../../objects/request.php";
    $donor=new Request();
    $donor->set_id($_POST['id'],$con);
    $donor->set_remarks($_POST['remark'],$con);
    $donor->set_status($_POST['acc'],$con);
    echo $donor->update_status($con);
    echo $donor->update_remarks($con);
?>