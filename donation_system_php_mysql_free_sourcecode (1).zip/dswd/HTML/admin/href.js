function change_location(loc){
    window.location=loc;                                                  
}