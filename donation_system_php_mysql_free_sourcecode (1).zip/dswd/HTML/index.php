<?php
    session_start();
    require_once'connect/coon.php';
    include'objects/broadcast.php';
    $broad=new Broadcast();
    $mes=$broad->select($con);
?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        
        <script src="jquery.min.js"></script>
        <meta charset="utf-8">
        <title>DSWD</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="jquery.min.js"></script>
        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'> 
        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Owl carousel -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
    <script src="assets/js/bootstrap.min.js"></script>
        <!-- Modernizr -->
    <script src="../assets/js/modernizr-2.6.2.min.js"></script>  
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>
        <style>
            .pendings{
                color: grey !important;
            }
            .accepteds{
                color: green !important;
            }
            .rejecteds{
                color: crimson !important;
            }
            .hoverr{
            font-size: 0.7em;
            color:blue;
            cursor: pointer;
            }
            .hoverr:hover{
                color:dodgerblue;
            }
        </style>
    </head>

    <body>
    <?php include'link/message.php'; ?>

    <header class="main-header">
        
    
        <nav class="navbar navbar-static-top">

            <div class="navbar-top">

              <div class="container">
                  <div class="row">
                     


                  </div>
              </div>

            </div>

            <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>
                  
                  <a class="navbar-brand" href="index.html"><img src="assets/images/vscwd-logo2.jpg" alt=""></a>
                  
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav" id="ang_nav">
                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->




    <!-- Carousel
    ================================================== -->
    <div id="homeCarousel" class="carousel slide carousel-home" data-ride="carousel">

          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#homeCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#homeCarousel" data-slide-to="1"></li>
              
            <li data-target="#homeCarousel" data-slide-to="2"></li>
          </ol>

          <div class="carousel-inner" role="listbox">

            <div class="item active">

              <img src="assets/images/slider/home-slider-1.jpg" alt="">

              <div class="container">

                <div class="carousel-caption">

                    <h2 class="carousel-title bounceInDown animated slow"><?php echo $mes; ?></h2>
                    <h4 class="carousel-subtitle bounceInUp animated slow "></h4>
                    <a href="#" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow" data-toggle="modal" data-target="#donateModal">
                        BE A DONOR
                    </a>
				

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->

            <div class="item ">

              <img src="assets/images/slider/home-slider-3.jpg" alt="">

              <div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" ><?php echo $mes; ?></h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <a href="#" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow" data-toggle="modal" data-target="#beniModal">BE A BENEFICIARY</a>

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->
              <div class="item ">

              <img src="assets/images/slider/home-slider-3.jpg" alt="">

              <div class="container">

                <div class="carousel-caption">

                  <h2 class="carousel-title bounceInDown animated slow" ><?php echo $mes; ?></h2>
                  <h4 class="carousel-subtitle bounceInUp animated slow"></h4>
                  <a href="#" class="btn btn-lg btn-secondary hidden-xs bounceInUp animated slow" data-toggle="modal" data-target="#volunModal">BE A Volunteer</a>

                </div> <!-- /.carousel-caption -->

              </div>

            </div> <!-- /.item -->

          </div>

          <a class="left carousel-control" href="#homeCarousel" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>

          <a class="right carousel-control" href="#homeCarousel" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>

    </div><!-- /.carousel -->
 
    <div class="section-home home-reasons">

        <div class="container">

            <div class="row">
                
                <div class="col-md-6">

                    <div class="reasons-col animate-onscroll fadeIn">

                        <img src="assets/images/reasons/we-fight-togother.jpg" alt="">

                        <div class="reasons-titles">

                            <h3 class="reasons-title">We fight together</h3>
                            <h5 class="reason-subtitle">We are humans</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">
                            
                                <p> </p>


                                <p> </p>

                                <p> </p>
                                
                        </div>
                    </div>
                    
                </div>


                <div class="col-md-6">

                    <div class="reasons-col animate-onscroll fadeIn">

                        <img src="assets/images/reasons/we-care-about.jpg" alt="">

                        <div class="reasons-titles">

                            <h3 class="reasons-title">WE care about others</h3>
                            <h5 class="reason-subtitle">We are humans</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">
                            
                                <p> </p>


                                <p> </p>

                                <p> </p>
                                
                        </div>


                    </div>
                    
                </div>


            </div>
          
  

        </div>
      

    </div> <!-- /.home-reasons -->
                    
                </div>

              



<!--
    <div class="section-home our-sponsors animate-onscroll fadeIn">
    
        <div class="container">

            <h2 class="title-style-1">Our Sponsors <span class="title-under"></span></h2>

            <ul class="owl-carousel list-unstyled list-sponsors">

              <li> <img src="assets/images/sponsors/bus.png" alt=""></li>
              <li> <img src="assets/images/sponsors/wikimedia.png" alt=""></li>
              <li> <img src="assets/images/sponsors/one-world.png" alt=""></li>
              <li> <img src="assets/images/sponsors/wikiversity.png" alt=""></li>
              <li> <img src="assets/images/sponsors/united-nations.png" alt=""></li>

              <li> <img src="assets/images/sponsors/bus.png" alt=""></li>
              <li> <img src="assets/images/sponsors/wikimedia.png" alt=""></li>
              <li> <img src="assets/images/sponsors/one-world.png" alt=""></li>
              <li> <img src="assets/images/sponsors/wikiversity.png" alt=""></li>
              <li> <img src="assets/images/sponsors/united-nations.png" alt=""></li>

            </ul>

        </div>

    </div>!--> <!-- /.our-sponsors -->


    


    <footer class="main-footer">

        <div class="footer-top">
            
        </div>


        <div class="footer-main">
            <div class="container">
                
                <div class="row">
                    <div class="col-md-4">

                        <div class="footer-col">

                            
                            
                        </div>

                    </div>

                     
                    <div class="clearfix"></div> 
                </div>
                
                
            </div>

            
        </div>
 
        
    </footer> <!-- main-footer -->




    <!-- Donate Modal -->
    <div class="modal fade" id="beniModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Be a Benificiary</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="beni_f">

                        <h3 class="title-style-1 text-center">Beneficiary Registration<span class="title-under"></span>  </h3>

                       <div class="row">
                            <div class="form-group col-md-12 ">
                                Upload Valid Document (Image or PDF)<input type="file" class="form-control" required accept="application/pdf,image/*" name="file">
                            </div>

                        </div>


                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="fname" placeholder="First name*">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="lname" placeholder="Last name*">
                            </div>
                        </div>


                        <div class="row">

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="contact" placeholder="Contact number">
                            </div>

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="address" placeholder="Address">
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="username" placeholder="Username">
                            </div>

                        </div>
                        <div class="row">

                            <div class="form-group col-md-6">
                                <input type="password" class="form-control" name="password" placeholder="Password" id="bpass">
                            </div>
                            <div class="form-group col-md-6">
                                <input type="password" class="form-control" name="repassword" placeholder="Retype Password" id="brepass">
                            </div>
                        </div> 
 
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow" id="b_iid" >Register</button>
                            </div>

                        </div>



                       
                    
                </form>
            
            
          </div>
        </div>
      </div>

    </div> <!-- /.modal -->
    
     <div class="modal fade" id="volunModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Be a Benificiary</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="volun_f">

                        <h3 class="title-style-1 text-center">Beneficiary Registration<span class="title-under"></span>  </h3>

                       <div class="row">
                            <div class="form-group col-md-12 ">
                                Upload Valid Document (Image or PDF)<input type="file" class="form-control" required accept="application/pdf,image/*" name="file">
                            </div>

                        </div>


                        <div class="row">
                            
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="fname" placeholder="First name*">
                            </div>
                            
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="mname" placeholder="Middle name*">
                            </div>
                            
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="lname" placeholder="Last name*">
                                
                            </div>
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="contact" placeholder="Contact number">
                            </div>
                            
                        </div>
 
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow" id="volun_iid" >Register</button>
                            </div>

                        </div>



                       
                    
                </form>
            
            
          </div>
        </div>
      </div>

    </div> <!-- /.modal -->

 <div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Be a Donor</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="donor_f">

                        <h3 class="title-style-1 text-center">Donor Registration<span class="title-under"></span>  </h3>
                        <div class="row">
                            <div class="form-group col-md-12 ">
                                Upload Valid Document  (Image or PDF)<input type="file" class="form-control" required accept="application/pdf,images/*">
                            </div>

                        </div>
                        <div class="row">

                            <div class="form-group col-md-12 ">
                                <input type="text" class="form-control php" name="fullname" placeholder="Fullname" d="d" required>
                            </div>

                        </div>


                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="contact" placeholder="Contact number" d="d" required>
                            </div>

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="username" placeholder="Username" d="d" required>
                            </div>
                        </div>


                        <div class="row">

                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="password" placeholder="password" d="d" required id="pass">
                            </div> 
                        </div>

                         <div class="row">

                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="repassword" placeholder="Retype Password" d="d" required id="repass">
                            </div> 
                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow" id="d_bid">Register</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal -->
    
    
 <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Login</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation log" id="login_f">

                        <h3 class="title-style-1 text-center">Login<span class="title-under"></span>  </h3>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <select type="text" class="form-control php" name="select_login" required id="selectionz">
                                    <option value="">Select User Type</option>
                                    <option>Beneficiary</option>
                                    <option>Donor</option>
                                </select>
                            </div>

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="username" placeholder="Username" d="d" required>
                            </div>
                        </div>


                        <div class="row">

                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="password" placeholder="password" d="d" required>
                            </div> 
                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow">Login</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal -->
    
 <div class="modal fade" id="changeModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Login</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation log" id="change_f">
                        <h3 class="title-style-1 text-center">Login<span class="title-under"></span></h3>
                        
                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="oldpassword" placeholder="password" d="d" required>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="newpassword" placeholder="password" d="d" required>
                            </div> 
                        </div>
                    <div class="row">
                            <div class="form-group col-md-12">
                                <input type="password" class="form-control php" name="retypepassword" placeholder="password" d="d" required>
                            </div> 
                        </div>
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow">Register</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal -->
    
    <div class="modal fade" id="donatesModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Send Donation</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="donates_f">

                        <h3 class="title-style-1 text-center">Donate now<span class="title-under"></span>  </h3>
                       

                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="type_of_donation" placeholder="Type of Donation" d="d" required>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="amount" placeholder="Amount" d="d" required>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea type="text" class="form-control php" name="detail" placeholder="Details" d="d" required></textarea>
                            </div> 
                        </div>
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow">Donate Now</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal --> 
     <div class="modal fade" id="reqModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Request for Donation</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="req_f">

                        <h3 class="title-style-1 text-center">Request for Donation<span class="title-under"></span>  </h3>
                       

                        <div class="row">
                            <div class="form-group col-md-12">
                                <textarea type="text" class="form-control php" name="desc" placeholder="Description of Request" d="d" required></textarea>
                            </div> 
                        </div>
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow">Request Now</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal --> 
    <style>
        .mod{
            width: 900px;
        }
        @media screen and (max-width:900px){
            .mod{
                width: 100%; 
            }
        }
    </style>
 <div class="modal fade " id="historyModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog mod">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">My Donation History</h4>
          </div>
          <div class="modal-body">
              <h3 class="title-style-1 text-center">My Donation History<span class="title-under"></span></h3>
              <table class="table" id="his_t">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type of Donation</th>
                        <th>Amount</th>
                        <th>Details </th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody id="tbod">
                   
                </tbody>
              </table>
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal -->
    
    <div class="modal fade " id="reqHistoryModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">
      <div class="modal-dialog mod">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">My Request History</h4>
          </div>
          <div class="modal-body">
              <h3 class="title-style-1 text-center">My Request History<span class="title-under"></span></h3>
              <table class="table" id="hist_t11">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Amount Received</th>
                        <th>Remarks</th> 
                        <th>Status </th>
                        
                    </tr>
                </thead>
                <tbody id="tbod1">
                   
                </tbody>
              </table>
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal -->
     <div class="modal fade" id="receiveModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">Received Amount</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation" id="receive_f">

                        <h3 class="title-style-1 text-center">Received Amount<span class="title-under"></span>  </h3>
                       

                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control php" name="type_of_donation" placeholder="Input Amount"id="amountz" required>
                            </div> 
                        </div> 
                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow">Submit</button> 
                            </div>

                        </div> 
                </form>
            
          </div>
        </div>
      </div>
     
    </div> <!-- /.modal --> 
    
    <div class="modal fade" id="cModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="donateModalLabel">Change Password</h4>
                  </div>
                  <div class="modal-body">

                        <form class="form-donation" id="cpass_f" action="user.php" method="post">

                            <h3 class="title-style-1 text-center">Change Password<span class="title-under"></span>  </h3>
                             <div class="row">
                                    <div class="form-group col-md-12 "> 
                                        <input type='password' class="form-control" required placeholder="Old Password"
                                        name='oldpassword'>
                                    </div>
                            </div>
                            <div class="row">
                                    <div class="form-group col-md-12 "> 
                                        <input type='password' class="form-control" required placeholder="New password"
                                        name='newpassword' id="cpass">
                                    </div>
                            </div>
                            <div class="row">
                                    <div class="form-group col-md-12 "> 
                                        <input type='password' class="form-control" required placeholder="Retype Password"
                                        name='repass' id="crepass">
                                    </div>
                            </div>
                                <div class="row">

                                    <div class="form-group col-md-12">
                                        <button type="submit" class="btn btn-primary pull-right" name="addd">Change</button> 
                                    </div>

                                </div> 
                        </form>

                  </div>
                </div>
              </div> 
    </div> <!-- /.modal -->

 
    <script src="php.js"></script>
    <script>
            var aja=new XMLHttpRequest || new webkitXMLHttpRequest || new msXMLHttpRequest || new oXMLHttpRequest || new mozXMLHttpRequest; 
            var aja1=new XMLHttpRequest || new webkitXMLHttpRequest || new msXMLHttpRequest || new oXMLHttpRequest || new mozXMLHttpRequest; 
            var bid;
            var fid;
            var mod_id;
            var volun_true=false;
            var logged="<?php echo isset($_SESSION['id_123']) ? 1 : 0; ?>";
            aja.upload.addEventListener("progress",(e)=>{
               document.getElementById(bid).innerHTML="please Wait.."+parseInt((e.loaded/e.total)*100)+"%";
            },false); 
            aja.addEventListener("load",(e)=>{  
                if(e.target.responseText==""){
                    if(volun_true==false){
                        alert("Successfully Registered! \n Please wait the admin is still verifying your account!");
                    }else{
                        alert("Successfully Registered! \n The Admin is now verifying your data!");
                    }
                    document.getElementById(mod_id).getElementsByClassName("close")[0].click(); 
                    document.getElementById(fid).reset()
                }else{
                    alert("Username is Already Taken!");
                }
                
                document.getElementById(bid).style.pointerEvents="all";
                document.getElementById(bid).innerHTML="Register";
            },false);  
            function logout(){
                $.ajax({
                    url:"panel_proc/logout.php",
                    method:"POST",
                    data:{},
                    success:(e)=>{
                        location.reload();
                    }
                });
            }
            function get_nav (){
                $.ajax({
                    url:"panel_proc/nav.php",
                    method:"POST",
                    data:{},
                    success:(e)=>{
                        ang_nav.innerHTML=e;
                    }
                });
            }
            get_nav();
            aja1.addEventListener("load",(e)=>{ 
                if(e.target.responseText=="Login Successfully"){
                    $('#loginModal').modal("hide");
                    get_nav();
                    logged=1; 
                    document.getElementsByClassName('log')[0].reset();
                    
                    document.getElementsByClassName('log')[1].reset();
                    req_notify();
                }else{
                    alert("Failed to login!");
                }
                get_nav();
            },false);
            function poost(json){  
                aja.open("POST",json.url);
                aja.send(json.data); 
            }
            function poost1(json){  
                aja1.open("POST",json.url);
                aja1.send(json.data); 
            }
            //////
            function serialize_form(id){
                var data=new FormData();
                for(var i=0;i<document.getElementById(id).getElementsByTagName('input').length;i++){  
                    if(document.getElementById(id).getElementsByTagName('input')[i].getAttribute("type")!="file"){
                        data.append(document.getElementById(id).getElementsByTagName('input')[i].getAttribute("name"),document.getElementById(id).getElementsByTagName('input')[i].value);
                    }else{
                        data.append("file",document.getElementById(id).getElementsByTagName('input')[i].files[0]); 
                    }
                }
                return data;
            }
            donor_f.addEventListener("submit",(e)=>{
                e.preventDefault();  
                if(confirm("Are you sure want to Register?")==false){
                    return;
                }
                if(pass.value==repass.value){ 
                    bid="d_bid";
                    fid="donor_f";
                    mod_id="donateModal";
                    document.getElementById(bid).style.pointerEvents="none";
                    poost({
                        url:"registration_proc/donor_reg.php",
                        data:serialize_form("donor_f")
                    });
                     repass.style.borderColor="rgba(0,0,0,0.2)";
                }else{
                    repass.style.borderColor="red";
                }
                
            },false);
           beni_f.addEventListener("submit",(e)=>{
                    e.preventDefault();  
                    if(confirm("Are you sure want to Register?")==false){
                        return;
                    }
                    if(bpass.value==brepass.value){ 
                        bid="b_iid";
                        fid="beni_f";
                        mod_id="beniModal";
                        document.getElementById(bid).style.pointerEvents="none";
                        poost({
                            url:"registration_proc/beni_reg.php",
                            data:serialize_form("beni_f")
                        });
                         brepass.style.borderColor="rgba(0,0,0,0.2)";
                    }else{
                        brepass.style.borderColor="red";
                    }

        },false);
        
        volun_f.addEventListener("submit",(e)=>{
            e.preventDefault();  
            if(confirm("Are you sure want to Register?")==false){
                return;
            } 
            bid="volun_iid";
            fid="volun_f";
            mod_id="volunModal";
            volun_true=true;
            var data=serialize_form("volun_f");
            data.append("insert","qwe");
            document.getElementById(bid).style.pointerEvents="none";
            document.getElementById(bid).style.pointerEvents="none";
            poost({
                url:"objects/volunter.php",
                data:data
            });
            brepass.style.borderColor="rgba(0,0,0,0.2)"; 

        },false);
        
        login_f.addEventListener("submit",(e)=>{
            var data=serialize_form("login_f");
            data.append("select_login",selectionz.value);
            var url= selectionz.value=="Beneficiary" ? "login_proc/bene.php" : "login_proc/donor.php";
            e.preventDefault();   
                poost1({
                    url:url,
                    data:data
                });
           },false);
        
        donates_f.addEventListener("submit",(e)=>{
            e.preventDefault();
            if(confirm("Are you sure you want to submit it?")==false){
                return false;
            }
            $.ajax({
                url:"insert_proc/donate_now.php",
                method:"POST",
                data:$('#donates_f').serializeArray(),
                success:(e)=>{ 
                    if(e==""){
                        alert("Donation Successfully Sent!");
                        document.getElementById('donatesModal').getElementsByClassName("close")[0].click(); 
                        document.getElementById('donates_f').reset();
                    }
                }
            })
        },false);
        
        req_f.addEventListener("submit",(e)=>{
            e.preventDefault();
            if(confirm("Are you sure you want to submit it?")==false){
                return false;
            }
            $.ajax({
                url:"insert_proc/req_now.php",
                method:"POST",
                data:$('#req_f').serializeArray(),
                success:(e)=>{ 
                    if(e==""){
                        alert("Request Successfully Sent!");
                        document.getElementById('reqModal').getElementsByClassName("close")[0].click(); 
                        document.getElementById('req_f').reset();
                        $('#reqModal').hide('modal');
                    }
                }
            })
        },false); 
        
        function get_history(){
             tbod.innerHTML="";
             $.ajax({
                    url:"select_proc/donor_details.php",
                    method:"POST",
                    data:{},
                    success:(e)=>{ 
                        tbod.innerHTML=e; 
                        $(document).ready(function(){
                        $('#his_t').DataTable({
                            responsive:false,
                            sort:false
                        });
                        });
                        $('#historyModal').modal("show");
                    }
                });
        }
        function get_reqhistory(){
             $.ajax({
                    url:"select_proc/req.php",
                    method:"POST",
                    data:{},
                    success:(e)=>{
                        tbod1.innerHTML="";
                        tbod1.innerHTML=e; 
                        $(document).ready(function(){ 
                        $('#hist_t11').DataTable({
                            responsive:false,
                            sort:false
                        });
                        });
                        $('#reqHistoryModal').modal("show");
                    }
                });
        }
        function readmore(id1,id2){
                    if(document.getElementById(id2).innerHTML=="..Read More"){
                        document.getElementById(id2).innerHTML=" hide";
                        document.getElementById(id1).style.display="inline";
                    }else{
                        document.getElementById(id2).innerHTML="..Read More";
                        document.getElementById(id1).style.display="none";
                    }
        } 
        var iddz="";
        function set_amount(id){ 
            iddz=id;
            $('#receiveModal').modal("show");
        }
        receive_f.addEventListener("submit",(e)=>{
            e.preventDefault();
            $.ajax({
                url:"insert_proc/receive.php",
                method:"post",
                data:{id:iddz,amount:amountz.value},
                success:(e)=>{ 
                    alert("Amount Successfully set!"); 
                    $('#receiveModal').modal("hide");
                    window.location.reload();
                    receive_f.reset();
                }
            })
        },false);
        function req_notify(){
            $.ajax({
                url:"select_proc/req_notif.php",
                method:"post",
                data:{},
                success:(e)=>{ 
                    if(e!=0&&logged==1){ 
                        notif.innerHTML=' ( '+e+' )';
                    }
                    window.setTimeout(()=>{
                        req_notify();
                    },2000);
                }
            });  
        }
        req_notify();
        var cath=0;
        cpass_f.addEventListener('submit',(e)=>{
        e.preventDefault();
        if(cpass.value!=crepass.value){
            alert("incorrect Retype Password!");
            return false;
        }
        var urls= cath==1 ? "panel_proc/changepass.php" : "panel_proc/changepass1.php";
        var data=$('#cpass_f').serialize();  
        $.ajax({
                method:"POST",
                url:urls,
                data:data,
                success:(e)=>{  
                    if(e==""){
                        alert("Account Successfully Updated!");
                        location.reload();
                    }else{
                        alert("Failed to Update Incorrect old password!");
                    }
                }
            });
    },false);
    function open_pass(req){
        cath=req;
    }
    </script>

    <!--  Scripts
    ================================================== -->

    <!-- jQuery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.1.min.js"><\/script>')</script>

    <!-- Bootsrap javascript file -->
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- owl carouseljavascript file -->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!-- Template main javascript -->
    <script src="assets/js/main.js"></script>

    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
    <script>
        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
        e.src='//www.google-analytics.com/analytics.js';
        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
        ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>

    </body>
</html>
